package com.example.thuchanhgui_bai1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        EditText editTextNumberA, editTextNumberB;
        TextView textViewResult;
        Button buttonSum, buttonSub, buttonMul, buttonDiv, buttonGcd, buttonExit;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextNumberA = findViewById(R.id.editTextNumberA);
        editTextNumberB = findViewById(R.id.editTextNumberB);
        textViewResult = findViewById(R.id.textViewResult);
        buttonSum = findViewById(R.id.buttonSum);
        buttonSub = findViewById(R.id.buttonSub);
        buttonMul = findViewById(R.id.buttonMul);
        buttonDiv = findViewById(R.id.buttonDiv);
        buttonGcd = findViewById(R.id.buttonGcd);
        buttonExit = findViewById(R.id.buttonExit);

        buttonSum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a = Integer.parseInt(editTextNumberA.getText().toString());
                int b = Integer.parseInt(editTextNumberB.getText().toString());
                int sum = a + b;
                textViewResult.setText(String.valueOf(sum));
            }
        });
        buttonSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a = Integer.parseInt(editTextNumberA.getText().toString());
                int b = Integer.parseInt(editTextNumberB.getText().toString());
                int sub = a - b;
                textViewResult.setText(String.valueOf(sub));
            }
        });
        buttonMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a = Integer.parseInt(editTextNumberA.getText().toString());
                int b = Integer.parseInt(editTextNumberB.getText().toString());
                int mul = a * b;
                textViewResult.setText(String.valueOf(mul));
            }
        });
        buttonDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a = Integer.parseInt(editTextNumberA.getText().toString());
                int b = Integer.parseInt(editTextNumberB.getText().toString());
                double div = (double) a / b;
                textViewResult.setText(String.valueOf(div));
            }
        });
        buttonExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        buttonGcd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}