package com.example.thuchanh17092024;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.view.View;
import android.widget.Button;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvDisplay = findViewById(R.id.tvDisplay);
        // Liên kết các nút với logic xử lý
        setupButtonClickListeners();
    }
    private TextView tvDisplay;
    private String expression = "";  // Biểu thức được nhập

    private void setupButtonClickListeners() {
        int[] buttonIds = new int[] {
                R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9,
                R.id.btnPlus, R.id.btnMinus, R.id.btnMultiply, R.id.btnDivide,
                R.id.btnOpen, R.id.btnClose, R.id.btnDot
        };

        // Gắn sự kiện cho các nút số và toán tử
        for (int id : buttonIds) {
            findViewById(id).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Button button = (Button) v;
                    expression += button.getText().toString();
                    tvDisplay.setText(expression);  // Hiển thị biểu thức
                }
            });
        }

        // Nút C để xóa toàn bộ biểu thức
        findViewById(R.id.btnC).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expression = "";
                tvDisplay.setText("0");
            }
        });

        // Nút DEL để xóa ký tự cuối cùng
        findViewById(R.id.btnDEL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (expression.length() > 0) {
                    expression = expression.substring(0, expression.length() - 1);
                    tvDisplay.setText(expression.isEmpty() ? "0" : expression);
                }
            }
        });

        // Nút = để tính toán kết quả
        findViewById(R.id.btnEquals).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // Sử dụng Rhino để đánh giá biểu thức toán học
                    Context rhino = Context.enter();
                    rhino.setOptimizationLevel(-1);
                    Scriptable scope = rhino.initStandardObjects();
                    String result = rhino.evaluateString(scope, expression, "JavaScript", 1, null).toString();
                    tvDisplay.setText(result);
                    expression = result;  // Cập nhật biểu thức với kết quả
                    Context.exit();
                } catch (Exception e) {
                    tvDisplay.setText("Error");
                    expression = "";  // Reset biểu thức nếu có lỗi
                }
            }
        });
    }
}

