package com.example.truyencuoi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import java.util.List;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ItemAdapter itemAdapter;
    List<Item> itemList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        itemList = new ArrayList<>();
        itemList.add(new Item("Con gái", R.drawable.congso));
        itemList.add(new Item("Cười 18", R.drawable.cuoi18));
        itemList.add(new Item("Cực hài", R.drawable.cuchai));
        itemList.add(new Item("Dân gian", R.drawable.dangian));
        itemList.add(new Item("Gia đình", R.drawable.giadinh));
        itemList.add(new Item("Giao thông", R.drawable.giaothong));
        itemList.add(new Item("Học sinh", R.drawable.hocsinh));

        itemAdapter = new ItemAdapter(this, itemList);
        recyclerView.setAdapter(itemAdapter);
    }
}