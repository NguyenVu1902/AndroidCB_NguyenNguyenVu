package com.example.truyencuoi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import java.util.List;
import java.util.ArrayList;
import android.content.Intent;


public class CategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        // Nhận dữ liệu từ Intent
        String categoryTitle = getIntent().getStringExtra("categoryTitle");

        // Cập nhật tiêu đề trên thanh ActionBar (hoặc TextView)
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(categoryTitle);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true); // Thêm nút back
        }
        RecyclerView recyclerView = findViewById(R.id.categoryRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Item> itemList = new ArrayList<>();
        if (categoryTitle.equals("Con gái")) {
            itemList.add(new Item("Việc học", R.drawable.icon));
            itemList.add(new Item("Đã hai lần rồi", R.drawable.icon));
            itemList.add(new Item("Cũng như nhau", R.drawable.icon));
            itemList.add(new Item("Rất lạnh", R.drawable.icon));
            itemList.add(new Item("Im lặng là vàng", R.drawable.icon));
            itemList.add(new Item("Bài học về tội nói dối", R.drawable.icon));
            itemList.add(new Item("Chưa chi đã đau", R.drawable.icon));
            itemList.add(new Item("1 xu và 1 phút", R.drawable.icon));
            itemList.add(new Item("Sao còn chưa thả?", R.drawable.icon));
            itemList.add(new Item("Di tích hóa thạch", R.drawable.icon));
            itemList.add(new Item("Nhầm lẫn tai hại", R.drawable.icon));
            itemList.add(new Item("Cảnh giác", R.drawable.icon));
        } else if (categoryTitle.equals("Cười 18")) {
            // Thêm các mục cho thể loại "Cười 18"
        }

        ItemAdapter itemAdapter = new ItemAdapter(this, itemList);
        recyclerView.setAdapter(itemAdapter);

        // Thêm OnClickListener vào adapter
        itemAdapter.setOnItemClickListener((position) -> {
            Intent intent = new Intent(CategoryActivity.this, DetailActivity.class);
            intent.putExtra("detailTitle", itemList.get(position).getTitle()); // Gửi tiêu đề item
            startActivity(intent);
        });
        recyclerView.setAdapter(itemAdapter);

    }
    @Override
    public boolean onSupportNavigateUp() {
        // Xử lý nút back
        onBackPressed();
        return true;
    }

}