package com.example.truyencuoi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;


public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        String detailTitle = getIntent().getStringExtra("detailTitle");

        TextView titleTextView = findViewById(R.id.titleTextView);
        titleTextView.setText(detailTitle);

        TextView contentTextView = findViewById(R.id.contentTextView);
        contentTextView.setText("Lúc bé, nghỉ học là chuyện lạ. Lớn lên mới biết, chuyện lạ là đi học."); // Đặt nội dung
    }
}